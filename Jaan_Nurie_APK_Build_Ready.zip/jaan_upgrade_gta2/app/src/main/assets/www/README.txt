JAAN ❤️ NURIE — COMPLETE 3D MOBILE PROTOTYPE

This is the most complete playable prototype delivered here for the requested private couples-life game.

FEATURES
- Private two-person room code; no public lobby/matchmaking.
- Jaan and Nurie are the two playable characters, using the supplied photo references.
- Mobile joystick and keyboard movement.
- Live WebRTC voice chat through PeerJS.
- Continuous in-game clock and day progression.
- 3D city environment with:
  • five-bedroom duplex
  • Jaan's construction HQ
  • Nurie's workplace
  • restaurant
  • hospital
  • airport
  • school
  • horse-riding area
  • roads, street lights, cars and many NPCs
- Black G-Wagon and white GLK visual references.
- Couple interaction: hug/cuddle.
- Family progression: pregnancy timeline, randomized single/twin birth, boy/girl outcomes, children aging and school location.
- Local persistent save.

RUN ON PHONE
1. Host this folder on an HTTPS website (or localhost for testing).
2. Open the same link on both phones.
3. Jaan taps Create our world and sends the private room code to Nurie.
4. Nurie taps Join our world and enters the code.
5. Both allow microphone access for live voice.

IMPORTANT
This is a real playable web/3D prototype, not a signed Google Play/App Store APK. A store-ready commercial release still requires native packaging/signing, secure backend accounts and persistence, production 3D character/vehicle/environment assets, animations, server infrastructure and testing. The gameplay systems and private two-player structure are included here as the working foundation.
